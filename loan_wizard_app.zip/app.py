
from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from config import Config

app = Flask(__name__)
app.config.from_object(Config)
db = SQLAlchemy(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/high_risk_borrowers')
def high_risk_borrowers():
    query = '''
    SELECT 
        u.UserID, u.Name AS Borrower, u.IncomeLevel, la.LoanID, la.AmountBorrowed,
        ir.InterestRate, COUNT(rs.ScheduleID) AS OverduePayments,
        (la.AmountBorrowed - COALESCE(SUM(th.AmountPaid), 0)) AS OutstandingBalance
    FROM 
        Users u
        JOIN LoanAmounts la ON u.UserID = la.UserID
        JOIN InterestRates ir ON la.LoanID = ir.LoanID
        LEFT JOIN RepaymentSchedules rs ON la.LoanID = rs.LoanID
        LEFT JOIN TransactionHistories th ON la.LoanID = th.LoanID
    WHERE 
        rs.Status = 'Pending' AND rs.DueDate < CURRENT_DATE
        AND ir.InterestRate > (SELECT AVG(InterestRate) FROM InterestRates)
        AND u.IncomeLevel = 'Low'
    GROUP BY 
        la.LoanID
    HAVING OverduePayments > 1;
    '''
    result = db.session.execute(query)
    rows = result.fetchall()
    return render_template('report.html', title="High-Risk Borrowers", rows=rows)

@app.route('/top_borrowers')
def top_borrowers():
    query = '''
    SELECT 
        u.UserID, u.Name AS Borrower, SUM(la.AmountBorrowed) AS TotalAmountBorrowed
    FROM 
        Users u
        JOIN LoanAmounts la ON u.UserID = la.UserID
    GROUP BY 
        u.UserID
    ORDER BY 
        TotalAmountBorrowed DESC
    LIMIT 10;
    '''
    result = db.session.execute(query)
    rows = result.fetchall()
    return render_template('report.html', title="Top Borrowers", rows=rows)

if __name__ == '__main__':
    app.run(debug=True)
